NAME='logcrypto'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['logcrypto']
