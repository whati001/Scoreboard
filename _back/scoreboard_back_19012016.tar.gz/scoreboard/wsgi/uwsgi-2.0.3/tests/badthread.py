def application(env, start_response):
	while 1:
		pass
